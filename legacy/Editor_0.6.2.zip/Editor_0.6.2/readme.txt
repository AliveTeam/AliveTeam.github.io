This application allows you to edit level scripts from both the PC version"Abes Exoddus" and "Abes Oddysee". It is 100% free and you should never be charged for it!

It expects the files in the orignal format (the .lvl archive(s)) I claim no ownership to anything to do with the Oddworld franchise.

If you need to contact me you can do so via Oddworld forums (Paul on OddworldForums.net)

Note that this application depends on the following:
QtCore4.dll
QtGui4.dll
QtOpenGL4.dll
QtXml4.dll

********** Changes ************

09:14 PM 02/11/2010 Version 0.1
-First version released.

04:41 PM 22/12/2010 Version 0.2
+ Fixed all known bugs and rewrote LVL archive loading/saving code (there will still be some issues)
+ Can delete objects
+ Can add objects
+ Can set which screen an object will load in
+ Added "run game" option to quickly launch the game from the editor
+ All objects have their own XML file to make it easier to document objects
+ All AO objects are named
+ Almost all AE objects are named
+ Added OpenGL rendering mode
+ Added snap to grid option
+ Added mini map UI

09:49 PM 28/12/2010 Version 0.3
+ Added collision item editor
+ Fixed a few minor bugs
+ 99% of AO objects fully documented

11:46 PM 29/12/2010 Version 0.4
+ Fixed courrpting issue when using command line tools
+ Fixed issues with read only lvls or locked lvls courrpting or failing to save
+ Ask user to save changes when closing / opening new path
+ Updated more XML objects for AO
+ OpenGL rendering now works in release mode, the application is now built with GNU g++ rather than MSVC

02:12 PM 02/01/2011 Version 0.5
+ Can now replace CAM images, add new CAMS / Remove FG1 blocks and export CAM's for AO only
+ Fixed some undocumented bugs

07:41 PM 09/01/2011 Version 0.6
+ Added shortcut keys
+ Disabled snapping by default (its somewhat buggy anyway)
+ Cleaned up AO ubx docs and added an image
+ Added statusbar messages

Outstanding issues:
* Moving collision items is not easy
* No collision item property editor
* Snap to grid may not work as expected in AO
* Rendering many items may be too slow on older machines
* Saving a readonly lvl may cause a crash
* No default properties for objects in XML
* Some other annoying usability issues
* Wrong values or anything slightly wrong will likely crash the game
* Unconfirmed but it also appears large lvl archives may crash the game
* Lots of missing images for each type of object
* Not currently possible to use hex notation in the XML files
* Toggle options can become out of sync
* Overlapping bytes in XML objects is not detected or reported
* When added new objects when the view is zoomed they will not be added where you expect
* No option to reload the xml after its been edited
* Scene rect will not always match the actual content size
* Xml needs to beable to set either signed or unsigned int types
* No undo/redo feature
* Rendering collision item lines takes a lot of CPU time (disable them if its too slow)
