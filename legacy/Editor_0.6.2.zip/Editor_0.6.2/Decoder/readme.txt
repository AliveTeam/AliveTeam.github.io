This application converts "cam" files from both the PC version"Abes Exodus" and "Abes Oddysee". It is 100% free and you should never be charged for it!

It expects the files in the orignal format (the .lvl archive(s)) I claim no ownership to anything to do with the Oddworld franchise.

If you need to contact me you can do so via my website at www.paulsapps.com


********** Changes ************

12:11 AM 27/07/2010 Version 0.1
-First version released.

10:16 PM 08/08/2010 Version 0.2
+Fixed bug where STP01C11.CAM did not convert properly
+Added decoding all of AO anim sprites.
*Issues with type 2 AO sprites converting
*Issues with the palts of some AO sprites
*All AO sprites with issues are prefixed with "Broken_"


06:36 PM 24/08/2010 Version 0.3
+Fixed bug where a typed directory path did not have a trailing dir seperator appended
+Added a log view to the main UI
+App will now extract and convert directly from lvl archives, so no need to extract them yourself before hand
+All sprites are now "glued" together into one big image rather than lots of small ones in seperate dirs
+Added options dialog to control what stuff is converted
+Any frame that has problems converting will be prefixed with Broken_XXX
*Issues have been found with ABEGAS.BAN SLOG.BAN and others where no or some frames are not found


07:43 PM 29/08/2010 Version 0.4
+Fixed issue with ABEGAS.BAN and others, *all* frames should now be found
+Added support for converting both AO and AE fonts
+Started support for AO sprites, many types are not yet support but lots still get converted
*Resulting tile sheets are no longer grouped by row, this may be fixed in the future
*Possible issue, green and blue are switched? In an old test the button sprite was pink, now its green! Also some bits of blue can be seen in Elum sprites
*All frames now have forced 20pixel gaps
*FG1 for AO a and AE not yet supported

01:09 AM 12/09/2010 Version 0.5
+Made cancel more responsive
+Support for AO and AE FG1 support
+All graphics formats now converted
*All previous issues remain, future versions will be bug fixes only
*Possible that the none LCD font colours are wrong
